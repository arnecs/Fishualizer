var classOnlineMapsTextureControl =
[
    [ "GetCoords", "classOnlineMapsTextureControl.html#a8b35a08644fc8eeea19485bcff09f32f", null ],
    [ "GetCoords", "classOnlineMapsTextureControl.html#a7c332351a9d0dbc4f4deac4b98d0eb80", null ],
    [ "SetTexture", "classOnlineMapsTextureControl.html#a17fabdfd94154b0c7b7b636beaffbfaa", null ],
    [ "instance", "classOnlineMapsTextureControl.html#adbbc7661149b5213e5303800d485ef7e", null ]
];