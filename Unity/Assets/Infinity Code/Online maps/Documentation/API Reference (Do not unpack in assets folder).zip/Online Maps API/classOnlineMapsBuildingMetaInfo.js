var classOnlineMapsBuildingMetaInfo =
[
    [ "info", "classOnlineMapsBuildingMetaInfo.html#a33030039c9c233e47945193251293370", null ],
    [ "title", "classOnlineMapsBuildingMetaInfo.html#a717f80bb246ef83bf913de2d7bdd61e4", null ]
];