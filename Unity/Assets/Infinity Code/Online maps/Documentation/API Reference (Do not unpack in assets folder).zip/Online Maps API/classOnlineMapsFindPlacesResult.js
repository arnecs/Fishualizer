var classOnlineMapsFindPlacesResult =
[
    [ "OnlineMapsFindPlacesResult", "classOnlineMapsFindPlacesResult.html#ae61d15acbd87181fda096e80578a53f8", null ],
    [ "formatted_address", "classOnlineMapsFindPlacesResult.html#a6b3d1e182247c9e9f8c0ee7e54924930", null ],
    [ "icon", "classOnlineMapsFindPlacesResult.html#ad79a5c24606ed29bf169395f495b393b", null ],
    [ "id", "classOnlineMapsFindPlacesResult.html#acadcd703b8e9d8cb33a8acb002e3c7d1", null ],
    [ "location", "classOnlineMapsFindPlacesResult.html#a2779bed8b7004d3fc8f6d59c190eea17", null ],
    [ "name", "classOnlineMapsFindPlacesResult.html#a959b2f4198c90402399ec56211267236", null ],
    [ "open_now", "classOnlineMapsFindPlacesResult.html#a60f3141d93aaca4b004a6191333459e3", null ],
    [ "photos", "classOnlineMapsFindPlacesResult.html#a4c7fc34aa014712f8cbc9beb268f5c66", null ],
    [ "place_id", "classOnlineMapsFindPlacesResult.html#a84404813360c3a2ef88f2924ea5b8253", null ],
    [ "price_level", "classOnlineMapsFindPlacesResult.html#a5c340a330162bab1f98b16540dd67d16", null ],
    [ "rating", "classOnlineMapsFindPlacesResult.html#a31ac47b76a6e2dca2f1bb3c2ff76a0e6", null ],
    [ "reference", "classOnlineMapsFindPlacesResult.html#a318f9a1e735c0baca2e7b1365f5e6eed", null ],
    [ "scope", "classOnlineMapsFindPlacesResult.html#a69259684017f1fc435ac6f5d09e5887c", null ],
    [ "types", "classOnlineMapsFindPlacesResult.html#a000b17e22568c64728c4e9475af8c9e7", null ],
    [ "vicinity", "classOnlineMapsFindPlacesResult.html#acfb3ccfe2a2239f22e6f69d58245efe3", null ],
    [ "weekday_text", "classOnlineMapsFindPlacesResult.html#a01f03d30245b5377cef88fed3ae641a6", null ]
];