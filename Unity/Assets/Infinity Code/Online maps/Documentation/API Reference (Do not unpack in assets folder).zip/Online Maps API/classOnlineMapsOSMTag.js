var classOnlineMapsOSMTag =
[
    [ "OnlineMapsOSMTag", "classOnlineMapsOSMTag.html#aa0f17f471eaf11f75120fcd5b1a1c676", null ],
    [ "key", "classOnlineMapsOSMTag.html#aebed9129ff5c25ca166e32e764e19ec2", null ],
    [ "value", "classOnlineMapsOSMTag.html#acfc2c6502ce1062e732716fb2fef1463", null ]
];