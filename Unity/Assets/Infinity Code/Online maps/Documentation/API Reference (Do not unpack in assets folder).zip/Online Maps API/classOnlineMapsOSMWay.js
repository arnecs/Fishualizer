var classOnlineMapsOSMWay =
[
    [ "OnlineMapsOSMWay", "classOnlineMapsOSMWay.html#ac3d642c0b4aa3471af0872f027c88b2f", null ],
    [ "nodeRefs", "classOnlineMapsOSMWay.html#a39bb2c0cbc960cbb755fa18a71ce8131", null ]
];