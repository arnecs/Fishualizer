var classOnlineMapsDirectionStep =
[
    [ "GetPoints", "classOnlineMapsDirectionStep.html#acf63285a11180934c259e87b9112f354", null ],
    [ "TryParse", "classOnlineMapsDirectionStep.html#a6a3feb2acefac1f2a5274e2ed95dc362", null ],
    [ "TryParseORS", "classOnlineMapsDirectionStep.html#a8bc255ccaa764691fe4f9df97e7cd91a", null ],
    [ "TryParseWithAlternatives", "classOnlineMapsDirectionStep.html#a164707dce07d78f2e9aea4123373fe77", null ],
    [ "distance", "classOnlineMapsDirectionStep.html#a53d21502f79e1fdf32024928188cd131", null ],
    [ "duration", "classOnlineMapsDirectionStep.html#aa48be2298ada79e19c2ddaa4bf32a88a", null ],
    [ "end", "classOnlineMapsDirectionStep.html#a9eea5e1348a464b0e634462d87267936", null ],
    [ "instructions", "classOnlineMapsDirectionStep.html#ad4b545b21cbef453ee5c99e1dcb23435", null ],
    [ "maneuver", "classOnlineMapsDirectionStep.html#a58f9024719bf6bf36ea135534b1ccd47", null ],
    [ "points", "classOnlineMapsDirectionStep.html#af0fe4dd28ee216b5befe1a1649f61f87", null ],
    [ "start", "classOnlineMapsDirectionStep.html#af0d840fb505d72e4e5cf1f5f209aac2d", null ],
    [ "stringInstructions", "classOnlineMapsDirectionStep.html#a9dc296bba6f24657f692abcf16428f42", null ]
];