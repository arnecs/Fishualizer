var searchData=
[
  ['value',['value',['../classOnlineMapsFindAutocompleteResultTerm.html#a99757df6a5ee22f955d43a60d45eec4f',1,'OnlineMapsFindAutocompleteResultTerm.value()'],['../classOnlineMapsOSMTag.html#acfc2c6502ce1062e732716fb2fef1463',1,'OnlineMapsOSMTag.value()']]],
  ['version',['version',['../classOnlineMaps.html#a7c65adcc394f9217d4baf75a3a3bc071',1,'OnlineMaps']]],
  ['vicinity',['vicinity',['../classOnlineMapsFindPlaceDetailsResult.html#a3e04f38fff0e4e202b8d7a6a74dee38b',1,'OnlineMapsFindPlaceDetailsResult.vicinity()'],['../classOnlineMapsFindPlacesResult.html#acfb3ccfe2a2239f22e6f69d58245efe3',1,'OnlineMapsFindPlacesResult.vicinity()']]]
];
