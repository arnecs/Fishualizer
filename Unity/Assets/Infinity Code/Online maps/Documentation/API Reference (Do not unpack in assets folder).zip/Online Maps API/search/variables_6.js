var searchData=
[
  ['formatted_5faddress',['formatted_address',['../classOnlineMapsFindPlaceDetailsResult.html#a3fb97545228a3ccd89626ded32470e22',1,'OnlineMapsFindPlaceDetailsResult.formatted_address()'],['../classOnlineMapsFindPlacesResult.html#a6b3d1e182247c9e9f8c0ee7e54924930',1,'OnlineMapsFindPlacesResult.formatted_address()']]],
  ['formatted_5fphone_5fnumber',['formatted_phone_number',['../classOnlineMapsFindPlaceDetailsResult.html#ae3ca7f2f4cd1731c96012e193dbbf955',1,'OnlineMapsFindPlaceDetailsResult']]]
];
