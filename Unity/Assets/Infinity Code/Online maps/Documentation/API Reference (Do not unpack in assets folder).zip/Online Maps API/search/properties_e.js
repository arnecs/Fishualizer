var searchData=
[
  ['url',['url',['../classOnlineMapsTile.html#ad977fae4ed625275bab08dc57ba8e53e',1,'OnlineMapsTile']]],
  ['uvrect',['uvRect',['../classOnlineMapsControlBase.html#ab6213f490fb4760d02214996eaffd737',1,'OnlineMapsControlBase']]]
];
