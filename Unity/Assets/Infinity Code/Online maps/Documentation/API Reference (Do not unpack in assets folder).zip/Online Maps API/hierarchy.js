var hierarchy =
[
    [ "IEnumerable", null, [
      [ "OnlineMapsXML", "classOnlineMapsXML.html", null ],
      [ "OnlineMapsXMLList", "classOnlineMapsXMLList.html", null ]
    ] ],
    [ "IEnumerator", null, [
      [ "OnlineMapsXMLEnum", "classOnlineMapsXMLEnum.html", null ],
      [ "OnlineMapsXMLListEnum", "classOnlineMapsXMLListEnum.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "OnlineMaps", "classOnlineMaps.html", null ],
      [ "OnlineMapsBuildingBase", "classOnlineMapsBuildingBase.html", [
        [ "OnlineMapsBuildingBuiltIn", "classOnlineMapsBuildingBuiltIn.html", null ]
      ] ],
      [ "OnlineMapsBuildings", "classOnlineMapsBuildings.html", null ],
      [ "OnlineMapsControlBase", "classOnlineMapsControlBase.html", [
        [ "OnlineMapsControlBase2D", "classOnlineMapsControlBase2D.html", [
          [ "OnlineMapsDFGUITextureControl", "classOnlineMapsDFGUITextureControl.html", null ],
          [ "OnlineMapsGUITextureControl", "classOnlineMapsGUITextureControl.html", null ],
          [ "OnlineMapsIGUITextureControl", "classOnlineMapsIGUITextureControl.html", null ],
          [ "OnlineMapsNGUITextureControl", "classOnlineMapsNGUITextureControl.html", null ],
          [ "OnlineMapsSpriteRendererControl", "classOnlineMapsSpriteRendererControl.html", null ],
          [ "OnlineMapsUIImageControl", "classOnlineMapsUIImageControl.html", null ],
          [ "OnlineMapsUIRawImageControl", "classOnlineMapsUIRawImageControl.html", null ]
        ] ],
        [ "OnlineMapsControlBase3D", "classOnlineMapsControlBase3D.html", [
          [ "OnlineMapsTextureControl", "classOnlineMapsTextureControl.html", null ],
          [ "OnlineMapsTileSetControl", "classOnlineMapsTileSetControl.html", null ]
        ] ]
      ] ],
      [ "OnlineMapsLocationService", "classOnlineMapsLocationService.html", null ],
      [ "OnlineMapsMarkerInstanceBase", "classOnlineMapsMarkerInstanceBase.html", [
        [ "OnlineMapsMarker3DInstance", "classOnlineMapsMarker3DInstance.html", null ],
        [ "OnlineMapsMarkerBillboard", "classOnlineMapsMarkerBillboard.html", null ]
      ] ],
      [ "OnlineMapsRWTConnector", "classOnlineMapsRWTConnector.html", null ]
    ] ],
    [ "OnlineMapsBuffer", "classOnlineMapsBuffer.html", null ],
    [ "OnlineMapsBuildingMaterial", "classOnlineMapsBuildingMaterial.html", null ],
    [ "OnlineMapsBuildingMetaInfo", "classOnlineMapsBuildingMetaInfo.html", null ],
    [ "OnlineMapsBuildingsNodeData", "classOnlineMapsBuildingsNodeData.html", null ],
    [ "OnlineMapsDirectionStep", "classOnlineMapsDirectionStep.html", null ],
    [ "OnlineMapsDrawingElement", "classOnlineMapsDrawingElement.html", [
      [ "OnlineMapsDrawingLine", "classOnlineMapsDrawingLine.html", null ],
      [ "OnlineMapsDrawingPoly", "classOnlineMapsDrawingPoly.html", null ],
      [ "OnlineMapsDrawingRect", "classOnlineMapsDrawingRect.html", null ]
    ] ],
    [ "OnlineMapsFindAutocompleteResult", "classOnlineMapsFindAutocompleteResult.html", null ],
    [ "OnlineMapsFindAutocompleteResultMatchedSubstring", "classOnlineMapsFindAutocompleteResultMatchedSubstring.html", null ],
    [ "OnlineMapsFindAutocompleteResultTerm", "classOnlineMapsFindAutocompleteResultTerm.html", null ],
    [ "OnlineMapsFindPlaceDetailsResult", "classOnlineMapsFindPlaceDetailsResult.html", null ],
    [ "OnlineMapsFindPlacesResult", "classOnlineMapsFindPlacesResult.html", null ],
    [ "OnlineMapsFindPlacesResultPhoto", "classOnlineMapsFindPlacesResultPhoto.html", null ],
    [ "OnlineMapsGetElevationResult", "classOnlineMapsGetElevationResult.html", null ],
    [ "OnlineMapsGoogleAPIQuery", "classOnlineMapsGoogleAPIQuery.html", [
      [ "OnlineMapsFindAutocomplete", "classOnlineMapsFindAutocomplete.html", null ],
      [ "OnlineMapsFindDirection", "classOnlineMapsFindDirection.html", null ],
      [ "OnlineMapsFindDirectionAdvanced", "classOnlineMapsFindDirectionAdvanced.html", null ],
      [ "OnlineMapsFindLocation", "classOnlineMapsFindLocation.html", null ],
      [ "OnlineMapsFindPlaceDetails", "classOnlineMapsFindPlaceDetails.html", null ],
      [ "OnlineMapsFindPlaces", "classOnlineMapsFindPlaces.html", null ],
      [ "OnlineMapsGetElevation", "classOnlineMapsGetElevation.html", null ],
      [ "OnlineMapsOpenRouteService", "classOnlineMapsOpenRouteService.html", null ],
      [ "OnlineMapsOSMAPIQuery", "classOnlineMapsOSMAPIQuery.html", null ]
    ] ],
    [ "OnlineMapsJPEGDecoder", "classOnlineMapsJPEGDecoder.html", null ],
    [ "OnlineMapsMarkerBase", "classOnlineMapsMarkerBase.html", [
      [ "OnlineMapsMarker", "classOnlineMapsMarker.html", null ],
      [ "OnlineMapsMarker3D", "classOnlineMapsMarker3D.html", null ]
    ] ],
    [ "OnlineMapsOSMBase", "classOnlineMapsOSMBase.html", [
      [ "OnlineMapsOSMNode", "classOnlineMapsOSMNode.html", null ],
      [ "OnlineMapsOSMRelation", "classOnlineMapsOSMRelation.html", null ],
      [ "OnlineMapsOSMWay", "classOnlineMapsOSMWay.html", null ]
    ] ],
    [ "OnlineMapsOSMRelationMember", "classOnlineMapsOSMRelationMember.html", null ],
    [ "OnlineMapsOSMTag", "classOnlineMapsOSMTag.html", null ],
    [ "OnlineMapsPositionRange", "classOnlineMapsPositionRange.html", null ],
    [ "OnlineMapsRange", "classOnlineMapsRange.html", null ],
    [ "OnlineMapsThreadManager", "classOnlineMapsThreadManager.html", null ],
    [ "OnlineMapsTile", "classOnlineMapsTile.html", null ],
    [ "OnlineMapsUtils", "classOnlineMapsUtils.html", null ],
    [ "OnlineMapsVector2i", "classOnlineMapsVector2i.html", null ],
    [ "XmlNamespaceManager", null, [
      [ "OnlineMapsXMLNamespaceManager", "classOnlineMapsXMLNamespaceManager.html", null ]
    ] ]
];